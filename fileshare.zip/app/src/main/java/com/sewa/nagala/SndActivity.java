package com.sewa.nagala;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SndActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private Button btnSelectFile;
	private Button btnStartServer;
	private TextView progressDetailText;
	private TextView statusText;
	private EditText ipInput;
	private ProgressBar progressBar;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.snd);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		btnSelectFile = findViewById(R.id.btnSelectFile);
		btnStartServer = findViewById(R.id.btnStartServer);
		progressDetailText = findViewById(R.id.progressDetailText);
		statusText = findViewById(R.id.statusText);
		ipInput = findViewById(R.id.ipInput);
		progressBar = findViewById(R.id.progressBar);
		fp.setType("*/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		btnSelectFile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		btnStartServer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startServerThread();
			}
		});
	}
	
	private void initializeLogic() {
		checkPermissions();
		
	} // onCreate අවසන් කරයි
	
	private int PORT = 8080;
	
	private void updateUI(final String status, final int progress, final String detail) {
		    runOnUiThread(new Runnable() {
			        @Override
			        public void run() {
				            try {
					                statusText.setText("Status: " + status);
					                progressBar.setProgress(progress);
					                progressDetailText.setText(detail);
					            } catch (Exception e) {}
				        }
			    });
	}
	
	private String formatSize(long size) {
		    if (size < 1024) return size + " B";
		    int exp = (int) (Math.log(size) / Math.log(1024));
		    String pre = "KMGTPE".charAt(exp - 1) + "";
		    return String.format("%.1f %sB", size / Math.pow(1024, exp), pre);
	}
	
	private String getIPAddress() {
		    try {
			        for (java.util.Enumeration<java.net.NetworkInterface> en = java.net.NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
				            java.net.NetworkInterface intf = en.nextElement();
				            for (java.util.Enumeration<java.net.InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
					                java.net.InetAddress inetAddress = enumIpAddr.nextElement();
					                if (!inetAddress.isLoopbackAddress() && inetAddress instanceof java.net.Inet4Address) return inetAddress.getHostAddress();
					            }
				        }
			    } catch (Exception ignored) {}
		    return "Unknown";
	}
	
	public void startServerThread() {
		    new Thread(new Runnable() {
			        @Override
			        public void run() {
				            try {
					                java.net.ServerSocket serverSocket = new java.net.ServerSocket(PORT);
					                updateUI("Server Started. IP: " + getIPAddress(), 0, "");
					                while (true) {
						                    java.net.Socket socket = serverSocket.accept();
						                    java.io.DataInputStream dis = new java.io.DataInputStream(socket.getInputStream());
						                    String fileName = dis.readUTF();
						                    long fileSize = dis.readLong();
						                    java.io.File downloadDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
						                    java.io.File file = new java.io.File(downloadDir, fileName);
						                    java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
						                    byte[] buffer = new byte[16384];
						                    int read;
						                    long totalRead = 0;
						                    while (totalRead < fileSize && (read = dis.read(buffer, 0, (int)Math.min(buffer.length, fileSize - totalRead))) != -1) {
							                        fos.write(buffer, 0, read);
							                        totalRead += read;
							                        int progress = (int) ((totalRead * 100) / fileSize);
							                        updateUI("Receiving: " + fileName, progress, progress + "% complete (" + formatSize(totalRead) + "/" + formatSize(fileSize) + ")");
							                    }
						                    fos.close();
						                    socket.close();
						                    updateUI("Received: " + fileName, 100, "Saved in Downloads");
						                }
					            } catch (Exception e) { updateUI("Server Error: " + e.getMessage(), 0, ""); }
				        }
			    }).start();
	}
	
	public void sendFile(final android.net.Uri uri, final String ip) {
		    new Thread(new Runnable() {
			        @Override
			        public void run() {
				            try {
					                java.net.Socket socket = new java.net.Socket(ip, PORT);
					                java.io.DataOutputStream dos = new java.io.DataOutputStream(socket.getOutputStream());
					                java.io.InputStream is = getContentResolver().openInputStream(uri);
					                android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
					                if (cursor != null && cursor.moveToFirst()) {
						                    String fileName = cursor.getString(cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME));
						                    long fileSize = cursor.getLong(cursor.getColumnIndex(android.provider.OpenableColumns.SIZE));
						                    cursor.close();
						                    dos.writeUTF(fileName);
						                    dos.writeLong(fileSize);
						                    byte[] buffer = new byte[16384];
						                    int read;
						                    long totalSent = 0;
						                    while ((read = is.read(buffer)) != -1) {
							                        dos.write(buffer, 0, read);
							                        totalSent += read;
							                        int progress = (int) ((totalSent * 100) / fileSize);
							                        updateUI("Sending: " + fileName, progress, progress + "% complete (" + formatSize(totalSent) + "/" + formatSize(fileSize) + ")");
							                    }
						                    dos.flush();
						                    is.close();
						                    socket.close();
						                }
					            } catch (Exception e) { updateUI("Send Error: " + e.getMessage(), 0, ""); }
				        }
			    }).start();
	}
	
	private void checkPermissions() {
		    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
			        if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
				            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
				        }
			    }
	}
	
	private void dummy() {
		
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				
				// පැරණි _filenames වෙනුවට මෙහි ඇති _filePath භාවිතා කරන්න
				if (_filePath != null && _filePath.size() > 0) {
					    sendFile(android.net.Uri.fromFile(new java.io.File(_filePath.get(0))), ipInput.getText().toString());
				}
				
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
}